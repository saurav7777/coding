export enum IntrumentType{
    CREDITCARD = "CREDITCARD",
    UPI = "UPI",
    DEBITCARD = "DEBITCARD",
    NETBANKING = "NETBANKING"
}