export enum IssuerType{
    HDFC = "HDFC",
    SBI = "SBI",
    ICICI = "ICICI",
    AXIS = "AXIS",
    AMEX = "AMEX",
    CITI = "CITI"
}