import { IntrumentType } from "../enum/IntrumentType";
import { IssuerType } from "../enum/IssuerType";
import { CreditCard } from "../models/instruments/creditCard";
import { DebitCard } from "../models/instruments/debitCard";
import { NetBanking } from "../models/instruments/netBanking";
import { UPI } from "../models/instruments/Upi";

class InstrumentFactory {
    public static getIntrument(intrumentType: IntrumentType, id: string, type: IntrumentType,
        issuer: IssuerType, relevanceScore: number) {
        switch (intrumentType) {
            case IntrumentType.CREDITCARD: {
                return new CreditCard(id, type, issuer, relevanceScore);
            }
            case IntrumentType.DEBITCARD: {
                return new DebitCard(id, type, issuer, relevanceScore);
            }
            case IntrumentType.NETBANKING: {
                return new NetBanking(id, type, issuer, relevanceScore);
            }
            case IntrumentType.UPI: {
                return new UPI(id, type, issuer, relevanceScore);
            }
            default: {
                throw new Error("Invalid intrumentType")
            }
        }
    }
}

export default InstrumentFactory;