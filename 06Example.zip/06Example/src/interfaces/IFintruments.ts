import { IntrumentType } from "../enum/IntrumentType";
import { IssuerType } from "../enum/IssuerType";

export class Instrument {
    id: string;
    type: IntrumentType;
    issuer: IssuerType;
    relevanceScore: number;

    constructor(id: string, type: IntrumentType, issuer: IssuerType, relevanceScore: number) {
        this.id = id;
        this.type = type;
        this.issuer = issuer;
        this.relevanceScore = relevanceScore;
    }

}