import config from "./config";
import { IntrumentType } from "./enum/IntrumentType";
import { IssuerType } from "./enum/IssuerType";
import { LOB } from "./enum/LOB";
import { Instrument } from "./interfaces/IFintruments";
import { Cart } from "./models/cart";
import { User } from "./models/user";

function comparotor (a: Instrument ,b: Instrument ) {
    const oredering =  config.COMMERCE.Ordering;

    const idxa = oredering.indexOf(a.type);
    const idxb = oredering.indexOf(b.type);

    if(idxa > idxb) {
        return 1;
    } else if (idxa < idxb) {
        return -1;
    } else {
        return a.relevanceScore - b.relevanceScore;
    }
}

const IntrumentList: Instrument[] = [];

IntrumentList.sort(comparotor);

export class PaymentServiceRec {

    class UPIRuleValidateWrapper extends Validate {
        validate()
    }

    class WAlletRuleValidateWrapper extends Validate {
        WAlletRuleValidateWrapper wallet;
        constructor(Validate obj) {
            wallet =  obj;
        }
    }


    ruleCheckVaild


    .validate(RuleValidateWrapper)

    WalletruleCheckVaild
    UPIruleCheckVaild

    public getPaymentRec(user: User, cart:Cart): Instrument[] {
        const lob: LOB = cart.lob;
        const amount: number = cart.amount;

        const reqIntrumentsList = user.intrumentsList;

        // filter for Upi enabled
        const isUpi = user.userContext.isUpiEnabled;
        const newIntrumenList = reqIntrumentsList;

        if(!isUpi) {
            for(const intrument of reqIntrumentsList) {
                if(intrument.type === IntrumentType.UPI ) {
                    const index = newIntrumenList.indexOf(intrument, 0);
                        if (index > -1) {
                            newIntrumenList.splice(index, 1);
                        }
                }
            }
        }

        // get supported payment instruments for LOB type
        .get(config, `config.${lob}.${}`, null)




        // sort on relevance factore for similar Intrument


        return [];
    }
}