const config = {
    CREDITCARDBILL: {
        CreditCard: {
            allowed: false,
            limt: 2000000
        },
        UPI: {
            allowed: true,
            limt: 2000000
        },
        DEBITCARD: {
            allowed: true,
            limt: 2000000
        },
        NETBANKING: {
            allowed: true,
            limt: 2000000
        },
        Ordering: ['UPI', 'NETBANKING', 'DEBITCARD']
    },
    COMMERCE: {
        CreditCard: {
            allowed: true,
            limt: 2000000
        },
        UPI: {
            allowed: true,
            limt: 2000000
        },
        DEBITCARD: {
            allowed: true,
            limt: 2000000
        },
        NETBANKING: {
            allowed: false,
            limt: 2000000
        },
        Ordering: ['UPI', 'NETBANKING', 'DEBITCARD']
    },
    INVESTMENT: {
        CreditCard: {
            allowed: false,
            limt: 2000000
        },
        UPI: {
            allowed: true,
            limt: 2000000
        },
        DEBITCARD: {
            allowed: true,
            limt: 2000000
        },
        NETBANKING: {
            allowed: false,
            limt: 2000000
        },
        Ordering: ['UPI', 'NETBANKING', 'DEBITCARD']
    }
}

export default config;