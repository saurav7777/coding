import { Instrument } from "../interfaces/IFintruments";

export class User {
    userId!: string;
    intrumentsList: Instrument[] = [];
    userContext!: UserContext;
}