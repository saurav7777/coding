import { IntrumentType } from "../../enum/IntrumentType";
import { IssuerType } from "../../enum/IssuerType";
import { Instrument } from "../../interfaces/IFintruments";

export class NetBanking extends Instrument {
    constructor(id: string, type: IntrumentType, issuer: IssuerType, relevanceScore: number) {
        super(id, type, issuer, relevanceScore);
    }
}