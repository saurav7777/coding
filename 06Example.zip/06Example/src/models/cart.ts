import { LOB } from "../enum/LOB";


export class Cart {
    amount: number;
    lob: LOB;
    itemsList: string[] = [];

    constructor(amount: number, lob:LOB) {
        this.amount = amount;
        this.lob = lob;
    }
}