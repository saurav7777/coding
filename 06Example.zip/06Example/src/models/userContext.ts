class UserContext {
    isUpiEnabled: boolean;

    constructor (isUpiEnabled: boolean) {
        this.isUpiEnabled = isUpiEnabled;
    }
}